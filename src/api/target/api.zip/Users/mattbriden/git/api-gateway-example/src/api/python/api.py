def lambda_handler(event, _context):
    return {
        "statusCode": 200,
        "body": "Request Successful"
    }
